﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;
namespace Golu
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            saveFileDialog1.Filter = "Text files (*.txt)|*.txt|All files (*.*)|*.*";


            saveFileDialog1.ShowDialog();
        }

       
        private void saveFileDialog1_FileOk(object sender, CancelEventArgs e)
        {
            try
            {
                if (saveFileDialog1.FileName != null)
                {
                    File.WriteAllText(saveFileDialog1.FileName, richTextBox1.Text);
                    MessageBox.Show("Saved Successfully", "Saved Successfully", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    richTextBox1.Text = string.Empty;
                }
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message, "Error occurred", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
